# ProfBench result package — TuringCorp Team Junior v1.1 (2026-09-10)

Raw model outputs, per-criterion judgments and decision-kernel picks behind the published
ProfBench results, so the scores can be re-derived independently.

## Re-deriving the overall score

Each row in `judge-ratings/profbench_per-criterion.jsonl` is one rubric criterion for one model
on one task, judged Yes/No. The official rubric protocol averages **within each task** and then
across tasks:

```python
import json, collections
rows = [json.loads(l) for l in open("judge-ratings/profbench_per-criterion.jsonl")]
by_task = collections.defaultdict(lambda: collections.defaultdict(lambda: [0, 0]))
for r in rows:
    s = by_task[r["model"]][r["task_id"]]
    s[0] += 1 if str(r["judge_rating"]).strip().lower() == "yes" else 0
    s[1] += 1
for m in sorted(by_task):
    per_task = [100 * yes / tot for yes, tot in by_task[m].values()]
    print(f"{m:8s} {sum(per_task) / len(per_task):5.1f}  ({len(per_task)} tasks)")
# team 63.3 (38 tasks) · ds 57.4 · o3 55.6  ← 同一批 38 题口径（every model completed）
```

`baseline-direct_profbench.jsonl` also contains two tasks that are outside the published
comparison set; filter to the task IDs present in the team file to reproduce the 38-task figures
exactly. Pooling all criteria together instead (ignoring the per-task average) gives
61.6 / 56.2 / 55.1 — the official protocol is the per-task average above, which is what the
published scores use.

## Files

| Path | Contents |
|---|---|
| `answers/team-junior-v1.1_profbench.jsonl` | Team answers: `content` (answer body) + `reason` (stated reasoning) |
| `answers/baseline-direct_profbench.jsonl` | Direct baseline answers |
| `judge-ratings/profbench_per-criterion.jsonl` | One row per criterion: `judge_rating` Yes/No, `criterion_type`, `criterion_weight` |
| `decision/decider-choice-team-vs-o3.jsonl` | Decision-kernel pick between the team draft and the official o3 draft, with confidence |
| `decision/position-swap-audit.jsonl` | Same comparison on a sample of tasks with option A/B exchanged |

## What this package deliberately does not contain

Benchmark question text; cost, latency or token accounting; internal model or vendor
identifiers; failure logs. Disclosure of coverage and exclusions is at the summary level
(see SCORES.txt) rather than itemised.
